# Mavima Alert Manager

Sistema de gestão de alertas integrado ao Jira e Elasticsearch, com autenticação e painel administrativo.